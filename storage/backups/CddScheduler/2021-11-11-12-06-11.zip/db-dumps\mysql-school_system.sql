
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
DROP TABLE IF EXISTS `buildings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `buildings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `buildings` WRITE;
/*!40000 ALTER TABLE `buildings` DISABLE KEYS */;
INSERT INTO `buildings` VALUES (1,'LCA','Loretta Cornell Arzadon Building',1,'2021-08-08 21:58:29','2021-09-01 23:15:10'),(2,'VPA','Voltiare P. Arzadon Building',1,'2021-08-08 21:58:33','2021-09-01 23:14:41'),(3,'LCR','Leisure Coast Resort',1,'2021-08-19 17:20:53','2021-09-01 23:13:51'),(4,'FAME','Feliza Arzadon Memorial Entifice Building',1,'2021-08-19 18:30:05','2021-09-01 23:15:47');
/*!40000 ALTER TABLE `buildings` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categories` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `courses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `courses` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `department_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `courses_department_id_foreign` (`department_id`),
  CONSTRAINT `courses_department_id_foreign` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `courses` WRITE;
/*!40000 ALTER TABLE `courses` DISABLE KEYS */;
INSERT INTO `courses` VALUES (1,1,'BS INFORMATION TECHNOLOGY','ITE','2021-08-08 21:10:20','2021-08-08 21:43:22'),(2,3,'BACHELOR OF SCIENCE IN HOSPITALITY MANAGEMENT','SHM','2021-08-19 16:53:55','2021-08-19 17:13:31'),(3,2,'BACHELOR OF SCIENCE IN ACCOUNTANCY','BSA','2021-10-28 08:26:48','2021-10-28 08:26:48');
/*!40000 ALTER TABLE `courses` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `curricula`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `curricula` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `course_id` bigint(20) unsigned NOT NULL,
  `effective_sy` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `curricula_course_id_foreign` (`course_id`),
  CONSTRAINT `curricula_course_id_foreign` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `curricula` WRITE;
/*!40000 ALTER TABLE `curricula` DISABLE KEYS */;
INSERT INTO `curricula` VALUES (1,1,'2018-2019','CMO 25 s2015 Revised PSGs',1,'2021-08-11 21:50:39','2021-11-10 06:33:34'),(2,2,'2018-2019','CMO No. 62',1,'2021-08-19 16:58:59','2021-10-28 08:31:51'),(3,3,'2018-2019','SA',1,'2021-10-28 08:27:33','2021-10-28 08:32:28'),(4,3,'2014-2015','SY',0,'2021-10-28 08:28:00','2021-10-28 08:32:28'),(5,1,'2014-2015','Old',0,'2021-11-10 05:43:47','2021-11-10 06:33:34');
/*!40000 ALTER TABLE `curricula` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `curriculum_subjects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `curriculum_subjects` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `curriculum_id` bigint(20) unsigned NOT NULL,
  `year` int(11) NOT NULL,
  `term` int(11) NOT NULL,
  `code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lec_hours` int(11) NOT NULL,
  `lab_hours` int(11) NOT NULL,
  `lec_units` int(11) NOT NULL,
  `lab_units` int(11) NOT NULL,
  `prereq` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `curriculum_subjects_curriculum_id_foreign` (`curriculum_id`),
  CONSTRAINT `curriculum_subjects_curriculum_id_foreign` FOREIGN KEY (`curriculum_id`) REFERENCES `curricula` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `curriculum_subjects` WRITE;
/*!40000 ALTER TABLE `curriculum_subjects` DISABLE KEYS */;
INSERT INTO `curriculum_subjects` VALUES (1,'942e01f7-85bd-423d-8a36-9a2be3fe7601',1,1,1,'ITC01','INTRODUCTION TO COMPUTING/INFO TECH',2,3,2,1,'','2021-08-17 18:20:24','2021-08-17 18:32:42'),(2,'942e01f7-cbc7-4d1c-92eb-0fd8399cb543',1,1,1,'ITC02','PROGRAMMING 1',2,3,2,1,'','2021-08-17 18:20:24','2021-08-17 18:20:24'),(3,'942e01f7-cca0-4a49-ba51-83d9e829d6db',1,1,2,'ITC03','PROGRAMMING 2',2,3,2,1,'ITC02','2021-08-17 18:20:24','2021-08-17 18:32:04'),(4,'942e0624-5af9-41e6-a81d-c23f6696f53c',1,1,1,'GEC01','UNDERSTANDING THE SELF',3,0,3,0,'','2021-08-17 18:32:04','2021-08-17 18:32:04'),(5,'942e0624-625c-4659-b5ee-9f8254634d4c',1,1,1,'GEC02','PURPOSIVE COMMUNICATION',3,0,3,0,'','2021-08-17 18:32:04','2021-08-17 18:32:04'),(6,'942e0624-7e0e-4fa9-a7f3-cdf6cebd9922',1,1,1,'GEC03','MATHEMATICS IN THE MODERN WORLD',3,0,3,0,'','2021-08-17 18:32:04','2021-08-17 18:32:04'),(7,'942e0624-7ed6-4079-8e4e-40053836a642',1,1,1,'PE01','PHYSICAL EDUCATION 1',2,0,2,0,'','2021-08-17 18:32:04','2021-08-17 18:32:04'),(8,'942e0624-7f9d-4fad-917a-ab359d02ebe3',1,1,1,'NSTP01','NSTP 1',3,0,3,0,'','2021-08-17 18:32:04','2021-08-17 18:32:04'),(9,'942e0624-8273-4e9e-923b-6eed4f74f258',1,1,2,'ITP01','INTRODUCTION TO HCI',2,3,2,1,'ITC02','2021-08-17 18:32:04','2021-08-17 18:32:04'),(10,'942e0624-8362-43b3-b15b-9680baac803b',1,1,2,'ITP02','DISCRETE MATHEMATICS',3,0,3,0,'','2021-08-17 18:32:04','2021-08-17 18:32:04'),(11,'942e0624-843f-4647-b879-8b1c90ac9e00',1,1,2,'GEC04','ETHICS',3,0,3,0,'','2021-08-17 18:32:04','2021-08-17 18:32:04'),(12,'942e0624-8512-433e-ac03-04736abebdae',1,1,2,'GEC05','ART APPRECIATION',3,0,3,0,'','2021-08-17 18:32:04','2021-08-17 18:32:04'),(13,'942e0624-85f0-48f6-9d18-f2782cd65eaa',1,1,2,'FIL01','KONTEKSTWALISADONG KOMUNIKASYON SA FILIPINO',3,0,3,0,'','2021-08-17 18:32:04','2021-08-24 22:17:52'),(14,'942e0624-870e-45b2-b99a-9eb28c7181cb',1,1,2,'PE02','SELF DEFENSE',2,0,2,0,'','2021-08-17 18:32:04','2021-08-17 18:32:04'),(15,'942e0624-8830-4c19-9151-07dd4ed0dccd',1,1,2,'NSTP02','NSTP 2',3,0,3,0,'','2021-08-17 18:32:04','2021-08-17 18:32:04'),(17,'94301763-adad-4d06-b7bd-40ce6aa5177e',1,2,1,'ITC04','DATA STRUCTURES AND ALGORITHMS',2,3,2,1,'ITC03','2021-08-18 19:11:57','2021-08-18 19:11:57'),(18,'94301764-09a1-4eb0-b8b9-c1433f95cb58',1,2,1,'ITP03','OBJECT-ORIENTED PROGRAMMING',2,3,2,1,'ITC03','2021-08-18 19:11:57','2021-08-18 19:11:57'),(19,'94301764-0ab7-4c00-ada7-1d994f49f47b',1,2,1,'ITP04','PLATFORM TECHNOLOGIES',2,3,2,1,'ITC03','2021-08-18 19:11:57','2021-08-18 19:11:57'),(20,'94301764-0bd3-4d60-8eed-e149e8bcb992',1,2,1,'GEC06','READING IN HISTORY',3,0,3,0,'','2021-08-18 19:11:57','2021-08-18 19:11:57'),(21,'94301764-6c99-43ba-ae37-28c0f62f487a',1,2,1,'GEC07','SCIENCE, TECHNOLOGY AND SOCIETY',3,0,3,0,'','2021-08-18 19:11:57','2021-08-18 19:11:57'),(22,'94301764-6e1b-4726-ad34-20572ea774df',1,2,1,'FIL02','FILIPINO SA IBA\'T - IBANG DISIPLINA',3,0,3,0,'','2021-08-18 19:11:57','2021-08-18 19:11:57'),(23,'94301764-6f33-492f-9f3f-9de5fc161ea2',1,2,1,'PE03','FIRST AID AND WATER SAFETY',2,0,2,0,'','2021-08-18 19:11:57','2021-08-18 19:11:57'),(24,'9430687f-2347-4bbd-b336-3138a84be716',1,2,2,'ITC05','INFORMATION MANAGEMENT',2,3,2,1,'ITC03','2021-08-18 22:58:45','2021-08-18 22:58:45'),(25,'9430687f-75a5-407d-9147-20f854401061',1,2,2,'ITP05','NETCENTRIC FUNDAMENTALS',2,3,2,1,'ITP04','2021-08-18 22:58:45','2021-08-18 22:58:45'),(26,'94306ad1-e760-484a-abf4-235ccbb38ce9',1,2,2,'ITP06','QUANTITATIVE METHODS (INCL. MODELING & SIMULATION)',3,0,3,0,'ITP02','2021-08-18 23:05:14','2021-08-18 23:05:14'),(27,'9431ead2-d66b-4513-b2a1-baed4358fa24',2,1,1,'GEC01','UNDERSTANDING THE SELF',3,0,3,0,'','2021-08-19 16:59:00','2021-08-24 21:29:39'),(28,'9431ead3-19f1-4e10-889b-c51a3200d239',2,1,1,'GEC02','PURPOSIVE COMMUNICATION',3,0,3,0,'','2021-08-19 16:59:00','2021-08-24 21:29:39'),(29,'9431ead3-19fb-422f-bb62-e011815b161e',2,1,1,'GEC03','MATHEMATICS IN THE MODERN WORLD',3,0,3,0,'','2021-08-19 16:59:00','2021-08-24 21:29:39'),(30,'9431ead3-1a02-4c1a-9569-39d7cf9268ae',2,1,1,'PE01','PHYSICAL FITNESS',2,0,2,0,'','2021-08-19 16:59:00','2021-08-24 21:29:39'),(31,'9431ead3-1a08-4e3f-b289-1d651990dd27',2,1,1,'NSTP01','CIVIC WELFARE TRAINING SERVICE 1/ RESERVE OFFICERS\' TRAINING CORPS 1',3,0,3,0,'','2021-08-19 16:59:00','2021-08-24 21:29:39'),(32,'9431ead3-1a0e-44a2-82f9-dacadba9e8af',2,1,1,'THC01','MACRO PERSPECTIVE OF TOURISM AND HOSPITALITY',3,0,3,0,'','2021-08-19 16:59:00','2021-08-24 21:29:39'),(33,'9431ead3-1a14-4915-8d72-811168ed97cd',2,1,1,'THC02','RISK MANAGEMENT AS APPLIED TO SAFETY, SECURITY AND SANITATION',1,6,1,2,'','2021-08-19 16:59:00','2021-08-24 21:29:39'),(34,'9431ead3-1a1a-41c1-9cde-60a9b77720f3',2,1,2,'GEC04','ETHICS',3,0,3,0,'','2021-08-19 16:59:00','2021-08-24 21:29:39'),(35,'9431ead3-1a1f-43b3-ad4f-19ad01ce82ab',2,1,2,'GEC05','ART APPRECIATION',3,0,3,0,'','2021-08-19 16:59:00','2021-08-24 21:29:39'),(36,'9431ead3-1a25-464e-81cc-a621a07e5358',2,1,2,'FIL01','KONTEKSTWALISADONG KOMUNIKASYON SA FILIPINO',3,0,3,0,'','2021-08-19 16:59:00','2021-08-24 21:29:39'),(37,'9431ead3-1a2b-4770-a965-e6a66b97569a',2,1,2,'PE02','SELF DEFENSE',2,0,2,0,'','2021-08-19 16:59:00','2021-08-24 21:29:39'),(38,'9431ead3-1a31-48a2-8375-479952d2ab34',2,1,2,'NSTP02','CIVIC WELFARE TRAINING SERVICE 2/ RESERVE OFFICERS\' TRAINING CORPS 2',3,0,3,0,'','2021-08-19 16:59:00','2021-08-24 21:29:39'),(39,'9431ead3-1a37-4844-aaa9-ea4be8906d50',2,1,2,'THC03','QUALITY SERVICE MANAGEMENT IN TOURISM AND HOSPITALITY',3,0,3,0,'THC 1, THC 2','2021-08-19 16:59:00','2021-08-24 21:29:39'),(40,'9431ead3-1a3c-4a2f-8f1f-817a154fbbe0',2,1,2,'HPC01','KITCHEN ESSENTIALS AND BASIC FOOD PREPARTION',1,6,1,0,'THC 2','2021-08-19 16:59:00','2021-08-24 21:29:39'),(41,'9431ead3-1a42-4d77-84d3-8cd1edb13ab4',2,1,2,'THB01','BUSINESS MARKETING',0,3,3,0,'','2021-08-19 16:59:00','2021-08-24 21:29:39'),(42,'94bd5925-8d7c-483c-95e2-fac89c176254',3,1,1,'GEC01','UNDERSTANDING THE SELF',3,0,3,0,'','2021-10-28 08:27:33','2021-10-28 08:27:33'),(43,'94bd594e-f172-47f9-b3af-f1e35a15d3dd',4,1,1,'GE01','AKSDLF;KJSADF',3,0,3,0,'','2021-10-28 08:28:00','2021-10-28 08:28:00'),(44,'94d7455f-f54f-4c54-abcf-da9d93affe4f',5,1,1,'ATE01','INTRO TO PROGRAMMING',3,0,3,0,'','2021-11-10 05:43:47','2021-11-10 05:50:21'),(45,'94d7455f-fcc4-4c82-b97f-3a9067bbb1a2',5,1,2,'ATE02','ADVANCE TO PROGRAMMING',3,0,3,0,'ITE02','2021-11-10 05:43:47','2021-11-10 05:50:21');
/*!40000 ALTER TABLE `curriculum_subjects` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `departments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `departments` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `departments` WRITE;
/*!40000 ALTER TABLE `departments` DISABLE KEYS */;
INSERT INTO `departments` VALUES (1,'SITE','SCHOOL OF INFORMATION TECHNOLOGY EDUCATION','2021-08-08 21:10:20','2021-08-08 21:10:20'),(2,'SBA','SCHOOL OF BUSINESS ADMINISTRATION','2021-08-08 21:34:16','2021-08-08 21:34:16'),(3,'SIHM','SCHOOL OF HOSPITALITY MANAGEMENT','2021-08-19 16:48:15','2021-08-19 16:48:15');
/*!40000 ALTER TABLE `departments` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `faculties`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `faculties` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `department_id` bigint(20) unsigned NOT NULL,
  `rate` double(8,2) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `first_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `middle_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `faculties_department_id_foreign` (`department_id`),
  CONSTRAINT `faculties_department_id_foreign` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `faculties` WRITE;
/*!40000 ALTER TABLE `faculties` DISABLE KEYS */;
INSERT INTO `faculties` VALUES (1,32,'10001',1,50.00,1,'2021-11-04 07:25:00','2021-11-04 07:25:00','Test','T','Test');
/*!40000 ALTER TABLE `faculties` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `faculty_subjects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `faculty_subjects` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `faculty_id` bigint(20) unsigned NOT NULL,
  `subject_code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `subject_title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `faculty_subjects` WRITE;
/*!40000 ALTER TABLE `faculty_subjects` DISABLE KEYS */;
INSERT INTO `faculty_subjects` VALUES (1,1,'GEC01','UNDERSTANDING THE SELF','2021-08-24 23:32:47','2021-08-24 23:32:47'),(2,1,'GEC02','PURPOSIVE COMMUNICATION','2021-08-24 23:32:47','2021-08-24 23:32:47'),(3,1,'GEC03','MATHEMATICS IN THE MODERN WORLD','2021-08-24 23:32:48','2021-08-24 23:32:48'),(4,1,'GEC04','ETHICS','2021-08-24 23:32:48','2021-08-24 23:32:48'),(5,1,'GEC05','ART APPRECIATION','2021-08-24 23:32:48','2021-08-24 23:32:48'),(6,1,'FIL01','KONTEKSTWALISADONG KOMUNIKASYON SA FILIPINO','2021-08-24 23:32:48','2021-08-24 23:32:48'),(7,1,'GEC06','READING IN HISTORY','2021-08-24 23:32:48','2021-08-24 23:32:48'),(8,1,'GEC07','SCIENCE, TECHNOLOGY AND SOCIETY','2021-08-24 23:32:48','2021-08-24 23:32:48'),(9,1,'FIL02','FILIPINO SA IBA\'T - IBANG DISIPLINA','2021-08-24 23:32:48','2021-08-24 23:32:48'),(11,6,'ITC01','INTRODUCTION TO COMPUTING/INFO TECH','2021-08-24 23:44:54','2021-08-24 23:44:54'),(12,6,'ITC02','PROGRAMMING 1','2021-08-24 23:44:54','2021-08-24 23:44:54'),(13,6,'ITC03','PROGRAMMING 2','2021-08-24 23:44:54','2021-08-24 23:44:54'),(15,2,'PE01','PHYSICAL EDUCATION 1','2021-08-25 00:09:44','2021-08-25 00:09:44'),(16,2,'NSTP01','NSTP 1','2021-08-25 00:09:44','2021-08-25 00:09:44'),(17,2,'PE02','SELF DEFENSE','2021-08-25 00:09:44','2021-08-25 00:09:44'),(18,2,'NSTP02','NSTP 2','2021-08-25 00:09:44','2021-08-25 00:09:44'),(19,4,'PE01','PHYSICAL EDUCATION 1','2021-09-07 05:58:43','2021-09-07 05:58:43'),(20,4,'NSTP01','NSTP 1','2021-09-07 05:58:43','2021-09-07 05:58:43'),(21,4,'PE02','SELF DEFENSE','2021-09-07 05:58:43','2021-09-07 05:58:43'),(22,4,'NSTP02','NSTP 2','2021-09-07 05:58:43','2021-09-07 05:58:43'),(23,4,'PE03','FIRST AID AND WATER SAFETY','2021-09-07 05:58:43','2021-09-07 05:58:43');
/*!40000 ALTER TABLE `faculty_subjects` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=62 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2014_10_12_000000_create_users_table',1),(2,'2014_10_12_100000_create_password_resets_table',1),(3,'2019_08_19_000000_create_failed_jobs_table',1),(4,'2021_07_01_032240_create_settings_table',1),(5,'2021_07_06_062421_create_departments_table',1),(6,'2021_07_06_062422_create_courses_table',1),(7,'2021_07_06_062628_create_buildings_table',1),(8,'2021_07_06_062659_create_room_types_table',1),(9,'2021_07_06_062723_create_rooms_table',1),(10,'2021_07_06_062912_create_faculties_table',1),(11,'2021_07_06_063922_create_categories_table',1),(31,'2021_08_04_081539_create_curricula_table',2),(47,'2021_08_04_081827_create_curriculum_subjects_table',3),(48,'2021_08_04_095139_create_subjects_table',3),(49,'2021_08_06_065127_create_sections_table',3),(50,'2021_08_06_070358_create_schedules_table',3),(51,'2021_08_11_054326_create_time_schedules_table',3),(55,'2021_08_19_033848_create_faculty_subjects_table',4),(58,'2021_09_03_052833_create_permission_tables',5),(60,'2021_09_03_133840_add_user_id_to_faculties_table',6),(61,'2021_11_10_133542_add_active_to_subjects_table',7);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `model_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `model_has_permissions` (
  `permission_id` bigint(20) unsigned NOT NULL,
  `model_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`model_id`,`model_type`),
  KEY `model_has_permissions_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `model_has_permissions` WRITE;
/*!40000 ALTER TABLE `model_has_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `model_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `model_has_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `model_has_roles` (
  `role_id` bigint(20) unsigned NOT NULL,
  `model_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`role_id`,`model_id`,`model_type`),
  KEY `model_has_roles_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `model_has_roles` WRITE;
/*!40000 ALTER TABLE `model_has_roles` DISABLE KEYS */;
INSERT INTO `model_has_roles` VALUES (1,'App\\Models\\User',1),(2,'App\\Models\\User',2),(3,'App\\Models\\User',19),(3,'App\\Models\\User',21),(3,'App\\Models\\User',22),(3,'App\\Models\\User',23),(3,'App\\Models\\User',24),(3,'App\\Models\\User',25),(3,'App\\Models\\User',26),(3,'App\\Models\\User',32);
/*!40000 ALTER TABLE `model_has_roles` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `permissions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `permissions_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `role_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role_has_permissions` (
  `permission_id` bigint(20) unsigned NOT NULL,
  `role_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`role_id`),
  KEY `role_has_permissions_role_id_foreign` (`role_id`),
  CONSTRAINT `role_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `role_has_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `role_has_permissions` WRITE;
/*!40000 ALTER TABLE `role_has_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `role_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `roles` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `roles_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'superadmin','web','2021-09-07 03:33:03','2021-09-07 03:33:03'),(2,'admin','web','2021-09-07 03:33:07','2021-09-07 03:33:07'),(3,'faculty','web','2021-09-07 03:33:10','2021-09-07 03:33:10');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `room_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `room_types` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `room_types` WRITE;
/*!40000 ALTER TABLE `room_types` DISABLE KEYS */;
INSERT INTO `room_types` VALUES (1,'LECTURE','2021-08-08 21:10:42','2021-08-08 21:10:42'),(2,'LABORATORY','2021-08-08 21:10:48','2021-08-08 21:10:48'),(3,'PE','2021-08-19 17:21:05','2021-08-19 17:21:05'),(4,'NSTP','2021-08-19 18:30:23','2021-08-19 18:30:23');
/*!40000 ALTER TABLE `room_types` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `rooms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rooms` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `capacity` int(11) NOT NULL,
  `building_id` bigint(20) unsigned NOT NULL,
  `room_type_id` bigint(20) unsigned DEFAULT NULL,
  `no_of_laboratories` tinyint(1) NOT NULL DEFAULT 0,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `is_room` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `rooms_building_id_foreign` (`building_id`),
  CONSTRAINT `rooms_building_id_foreign` FOREIGN KEY (`building_id`) REFERENCES `buildings` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `rooms` WRITE;
/*!40000 ALTER TABLE `rooms` DISABLE KEYS */;
INSERT INTO `rooms` VALUES (1,'L303',50,1,2,0,1,1,'2021-08-08 21:58:50','2021-08-19 17:21:41'),(2,'L404',50,1,2,0,1,1,'2021-08-08 21:58:58','2021-08-08 21:58:58'),(3,'L302',50,1,1,0,1,1,'2021-08-09 21:11:33','2021-08-09 21:11:33'),(4,'V201',50,2,1,0,1,1,'2021-08-12 19:38:06','2021-08-12 19:38:06'),(5,'V202',50,2,1,0,1,1,'2021-08-12 19:38:13','2021-08-12 19:38:13'),(6,'L305',50,1,1,0,1,1,'2021-08-18 22:46:31','2021-08-19 17:21:59'),(7,'L301',50,1,1,0,1,1,'2021-08-18 22:47:20','2021-08-18 22:47:20'),(8,'L304',50,1,1,0,1,1,'2021-08-18 22:47:40','2021-08-19 17:21:53'),(9,'GYM',50,3,3,0,1,0,'2021-08-19 17:22:10','2021-08-19 17:22:10'),(10,'NSTP',50,3,4,0,1,0,'2021-08-19 18:35:19','2021-08-19 18:35:19');
/*!40000 ALTER TABLE `rooms` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `schedules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `schedules` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `school_year` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `term` int(11) NOT NULL,
  `section_id` bigint(20) unsigned NOT NULL,
  `subject_id` bigint(20) unsigned NOT NULL,
  `faculty_id` bigint(20) unsigned DEFAULT NULL,
  `lab` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `schedules_section_id_foreign` (`section_id`),
  KEY `schedules_subject_id_foreign` (`subject_id`),
  CONSTRAINT `schedules_section_id_foreign` FOREIGN KEY (`section_id`) REFERENCES `sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `schedules_subject_id_foreign` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `schedules` WRITE;
/*!40000 ALTER TABLE `schedules` DISABLE KEYS */;
/*!40000 ALTER TABLE `schedules` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `sections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sections` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `course_id` bigint(20) unsigned NOT NULL,
  `school_year` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `year` int(11) NOT NULL,
  `term` int(11) NOT NULL,
  `block` int(11) NOT NULL,
  `graduating` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sections_course_id_foreign` (`course_id`),
  CONSTRAINT `sections_course_id_foreign` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=108 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `sections` WRITE;
/*!40000 ALTER TABLE `sections` DISABLE KEYS */;
INSERT INTO `sections` VALUES (1,1,'2021-2022',1,1,1,0,'2021-08-17 18:20:31','2021-08-17 18:20:31'),(3,1,'2021-2022',1,1,2,0,'2021-08-18 22:48:08','2021-08-18 22:48:08'),(4,1,'2021-2022',2,1,1,0,'2021-08-18 22:49:13','2021-08-18 22:49:13'),(10,2,'2021-2022',1,1,1,0,'2021-08-19 17:22:40','2021-08-19 17:22:40'),(14,2,'2021-2022',1,1,2,0,'2021-08-26 17:56:32','2021-08-26 17:56:32'),(15,1,'2022-2023',1,1,1,0,'2021-08-31 22:29:44','2021-08-31 22:29:44'),(16,3,'2021-2022',1,1,1,0,'2021-10-28 08:33:42','2021-10-28 08:33:42'),(74,1,'2021-2022',4,2,1,0,'2021-11-04 08:34:46','2021-11-04 08:34:46'),(75,2,'2021-2022',1,2,1,0,'2021-11-04 08:34:46','2021-11-04 08:34:46'),(76,2,'2021-2022',2,2,1,0,'2021-11-04 08:34:46','2021-11-04 08:34:46'),(77,2,'2021-2022',3,2,1,0,'2021-11-04 08:34:47','2021-11-04 08:34:47'),(78,2,'2021-2022',4,2,1,0,'2021-11-04 08:34:47','2021-11-04 08:34:47'),(79,3,'2021-2022',1,2,1,0,'2021-11-04 08:34:47','2021-11-04 08:34:47'),(80,3,'2021-2022',2,2,1,0,'2021-11-04 08:34:47','2021-11-04 08:34:47'),(82,3,'2021-2022',4,2,1,0,'2021-11-04 08:34:47','2021-11-04 08:34:47'),(86,1,'2021-2022',4,2,2,0,'2021-11-04 08:35:10','2021-11-04 08:35:10'),(87,2,'2021-2022',1,2,2,0,'2021-11-04 08:35:10','2021-11-04 08:35:10'),(89,2,'2021-2022',3,2,2,0,'2021-11-04 08:35:10','2021-11-04 08:35:10'),(90,2,'2021-2022',4,2,2,0,'2021-11-04 08:35:10','2021-11-04 08:35:10'),(91,3,'2021-2022',1,2,2,0,'2021-11-04 08:35:10','2021-11-04 08:35:10'),(92,3,'2021-2022',2,2,2,0,'2021-11-04 08:35:11','2021-11-04 08:35:11'),(94,3,'2021-2022',4,2,2,0,'2021-11-04 08:35:11','2021-11-04 08:35:11'),(97,1,'2021-2022',3,2,2,0,'2021-11-04 08:37:10','2021-11-04 08:37:10'),(99,2,'2021-2022',1,2,3,0,'2021-11-04 08:37:10','2021-11-04 08:37:10'),(100,2,'2021-2022',2,2,2,0,'2021-11-04 08:37:10','2021-11-04 08:37:10'),(101,2,'2021-2022',3,2,3,0,'2021-11-04 08:37:10','2021-11-04 08:37:10'),(102,2,'2021-2022',4,2,3,0,'2021-11-04 08:37:10','2021-11-04 08:37:10'),(103,3,'2021-2022',1,2,3,0,'2021-11-04 08:37:10','2021-11-04 08:37:10'),(106,3,'2021-2022',4,2,3,0,'2021-11-04 08:37:10','2021-11-04 08:37:10'),(107,1,'2021-2022',1,2,1,0,'2021-11-10 05:42:39','2021-11-10 05:42:39');
/*!40000 ALTER TABLE `sections` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `settings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `school_year` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `term` smallint(6) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `settings` WRITE;
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
INSERT INTO `settings` VALUES (1,'2021-2022',2,NULL,'2021-11-04 08:02:08');
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `subjects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `subjects` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `course_id` bigint(20) unsigned NOT NULL,
  `curriculum_id` bigint(20) unsigned NOT NULL,
  `year` int(11) NOT NULL,
  `term` int(11) NOT NULL,
  `code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lec_hours` int(11) NOT NULL DEFAULT 0,
  `lab_hours` int(11) NOT NULL DEFAULT 0,
  `lec_units` int(11) NOT NULL DEFAULT 0,
  `lab_units` int(11) NOT NULL DEFAULT 0,
  `prereq` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `subjects_course_id_foreign` (`course_id`),
  KEY `subjects_curriculum_id_foreign` (`curriculum_id`),
  CONSTRAINT `subjects_course_id_foreign` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`) ON DELETE CASCADE,
  CONSTRAINT `subjects_curriculum_id_foreign` FOREIGN KEY (`curriculum_id`) REFERENCES `curricula` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=251 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `subjects` WRITE;
/*!40000 ALTER TABLE `subjects` DISABLE KEYS */;
INSERT INTO `subjects` VALUES (207,'9431ead2-d66b-4513-b2a1-baed4358fa24',2,2,1,1,'GEC01','UNDERSTANDING THE SELF',3,0,3,0,'','2021-11-10 06:31:43','2021-11-10 06:31:43',1),(208,'9431ead3-19f1-4e10-889b-c51a3200d239',2,2,1,1,'GEC02','PURPOSIVE COMMUNICATION',3,0,3,0,'','2021-11-10 06:31:43','2021-11-10 06:31:43',1),(209,'9431ead3-19fb-422f-bb62-e011815b161e',2,2,1,1,'GEC03','MATHEMATICS IN THE MODERN WORLD',3,0,3,0,'','2021-11-10 06:31:43','2021-11-10 06:31:43',1),(210,'9431ead3-1a02-4c1a-9569-39d7cf9268ae',2,2,1,1,'PE01','PHYSICAL FITNESS',2,0,2,0,'','2021-11-10 06:31:43','2021-11-10 06:31:43',1),(211,'9431ead3-1a08-4e3f-b289-1d651990dd27',2,2,1,1,'NSTP01','CIVIC WELFARE TRAINING SERVICE 1/ RESERVE OFFICERS\' TRAINING CORPS 1',3,0,3,0,'','2021-11-10 06:31:43','2021-11-10 06:31:43',1),(212,'9431ead3-1a0e-44a2-82f9-dacadba9e8af',2,2,1,1,'THC01','MACRO PERSPECTIVE OF TOURISM AND HOSPITALITY',3,0,3,0,'','2021-11-10 06:31:43','2021-11-10 06:31:43',1),(213,'9431ead3-1a14-4915-8d72-811168ed97cd',2,2,1,1,'THC02','RISK MANAGEMENT AS APPLIED TO SAFETY, SECURITY AND SANITATION',1,6,1,2,'','2021-11-10 06:31:43','2021-11-10 06:31:43',1),(214,'9431ead3-1a1a-41c1-9cde-60a9b77720f3',2,2,1,2,'GEC04','ETHICS',3,0,3,0,'','2021-11-10 06:31:43','2021-11-10 06:31:43',1),(215,'9431ead3-1a1f-43b3-ad4f-19ad01ce82ab',2,2,1,2,'GEC05','ART APPRECIATION',3,0,3,0,'','2021-11-10 06:31:43','2021-11-10 06:31:43',1),(216,'9431ead3-1a25-464e-81cc-a621a07e5358',2,2,1,2,'FIL01','KONTEKSTWALISADONG KOMUNIKASYON SA FILIPINO',3,0,3,0,'','2021-11-10 06:31:43','2021-11-10 06:31:43',1),(217,'9431ead3-1a2b-4770-a965-e6a66b97569a',2,2,1,2,'PE02','SELF DEFENSE',2,0,2,0,'','2021-11-10 06:31:43','2021-11-10 06:31:43',1),(218,'9431ead3-1a31-48a2-8375-479952d2ab34',2,2,1,2,'NSTP02','CIVIC WELFARE TRAINING SERVICE 2/ RESERVE OFFICERS\' TRAINING CORPS 2',3,0,3,0,'','2021-11-10 06:31:43','2021-11-10 06:31:43',1),(219,'9431ead3-1a37-4844-aaa9-ea4be8906d50',2,2,1,2,'THC03','QUALITY SERVICE MANAGEMENT IN TOURISM AND HOSPITALITY',3,0,3,0,'THC 1, THC 2','2021-11-10 06:31:43','2021-11-10 06:31:43',1),(220,'9431ead3-1a3c-4a2f-8f1f-817a154fbbe0',2,2,1,2,'HPC01','KITCHEN ESSENTIALS AND BASIC FOOD PREPARTION',1,6,1,0,'THC 2','2021-11-10 06:31:43','2021-11-10 06:31:43',1),(221,'9431ead3-1a42-4d77-84d3-8cd1edb13ab4',2,2,1,2,'THB01','BUSINESS MARKETING',0,3,3,0,'','2021-11-10 06:31:43','2021-11-10 06:31:43',1),(222,'94bd5925-8d7c-483c-95e2-fac89c176254',3,3,1,1,'GEC01','UNDERSTANDING THE SELF',3,0,3,0,'','2021-11-10 06:31:43','2021-11-10 06:31:43',1),(223,'94d7455f-f54f-4c54-abcf-da9d93affe4f',1,5,1,1,'ATE01','INTRO TO PROGRAMMING',3,0,3,0,'','2021-11-10 06:31:43','2021-11-10 06:39:43',0),(224,'94d7455f-fcc4-4c82-b97f-3a9067bbb1a2',1,5,1,2,'ATE02','ADVANCE TO PROGRAMMING',3,0,3,0,'ITE02','2021-11-10 06:31:43','2021-11-10 06:39:43',0),(225,'942e01f7-85bd-423d-8a36-9a2be3fe7601',1,1,1,1,'ITC01','INTRODUCTION TO COMPUTING/INFO TECH',2,3,2,1,'','2021-11-10 06:33:40','2021-11-10 06:33:40',1),(226,'942e01f7-cbc7-4d1c-92eb-0fd8399cb543',1,1,1,1,'ITC02','PROGRAMMING 1',2,3,2,1,'','2021-11-10 06:33:40','2021-11-10 06:33:40',1),(227,'942e01f7-cca0-4a49-ba51-83d9e829d6db',1,1,1,2,'ITC03','PROGRAMMING 2',2,3,2,1,'ITC02','2021-11-10 06:33:40','2021-11-10 06:33:40',1),(228,'942e0624-5af9-41e6-a81d-c23f6696f53c',1,1,1,1,'GEC01','UNDERSTANDING THE SELF',3,0,3,0,'','2021-11-10 06:33:40','2021-11-10 06:33:40',1),(229,'942e0624-625c-4659-b5ee-9f8254634d4c',1,1,1,1,'GEC02','PURPOSIVE COMMUNICATION',3,0,3,0,'','2021-11-10 06:33:40','2021-11-10 06:33:40',1),(230,'942e0624-7e0e-4fa9-a7f3-cdf6cebd9922',1,1,1,1,'GEC03','MATHEMATICS IN THE MODERN WORLD',3,0,3,0,'','2021-11-10 06:33:40','2021-11-10 06:33:40',1),(231,'942e0624-7ed6-4079-8e4e-40053836a642',1,1,1,1,'PE01','PHYSICAL EDUCATION 1',2,0,2,0,'','2021-11-10 06:33:40','2021-11-10 06:33:40',1),(232,'942e0624-7f9d-4fad-917a-ab359d02ebe3',1,1,1,1,'NSTP01','NSTP 1',3,0,3,0,'','2021-11-10 06:33:40','2021-11-10 06:33:40',1),(233,'942e0624-8273-4e9e-923b-6eed4f74f258',1,1,1,2,'ITP01','INTRODUCTION TO HCI',2,3,2,1,'ITC02','2021-11-10 06:33:40','2021-11-10 06:33:40',1),(234,'942e0624-8362-43b3-b15b-9680baac803b',1,1,1,2,'ITP02','DISCRETE MATHEMATICS',3,0,3,0,'','2021-11-10 06:33:40','2021-11-10 06:33:40',1),(235,'942e0624-843f-4647-b879-8b1c90ac9e00',1,1,1,2,'GEC04','ETHICS',3,0,3,0,'','2021-11-10 06:33:40','2021-11-10 06:33:40',1),(236,'942e0624-8512-433e-ac03-04736abebdae',1,1,1,2,'GEC05','ART APPRECIATION',3,0,3,0,'','2021-11-10 06:33:40','2021-11-10 06:33:40',1),(237,'942e0624-85f0-48f6-9d18-f2782cd65eaa',1,1,1,2,'FIL01','KONTEKSTWALISADONG KOMUNIKASYON SA FILIPINO',3,0,3,0,'','2021-11-10 06:33:40','2021-11-10 06:33:40',1),(238,'942e0624-870e-45b2-b99a-9eb28c7181cb',1,1,1,2,'PE02','SELF DEFENSE',2,0,2,0,'','2021-11-10 06:33:40','2021-11-10 06:33:40',1),(239,'942e0624-8830-4c19-9151-07dd4ed0dccd',1,1,1,2,'NSTP02','NSTP 2',3,0,3,0,'','2021-11-10 06:33:40','2021-11-10 06:33:40',1),(240,'94301763-adad-4d06-b7bd-40ce6aa5177e',1,1,2,1,'ITC04','DATA STRUCTURES AND ALGORITHMS',2,3,2,1,'ITC03','2021-11-10 06:33:40','2021-11-10 06:33:40',1),(241,'94301764-09a1-4eb0-b8b9-c1433f95cb58',1,1,2,1,'ITP03','OBJECT-ORIENTED PROGRAMMING',2,3,2,1,'ITC03','2021-11-10 06:33:40','2021-11-10 06:33:40',1),(242,'94301764-0ab7-4c00-ada7-1d994f49f47b',1,1,2,1,'ITP04','PLATFORM TECHNOLOGIES',2,3,2,1,'ITC03','2021-11-10 06:33:40','2021-11-10 06:33:40',1),(243,'94301764-0bd3-4d60-8eed-e149e8bcb992',1,1,2,1,'GEC06','READING IN HISTORY',3,0,3,0,'','2021-11-10 06:33:40','2021-11-10 06:33:40',1),(244,'94301764-6c99-43ba-ae37-28c0f62f487a',1,1,2,1,'GEC07','SCIENCE, TECHNOLOGY AND SOCIETY',3,0,3,0,'','2021-11-10 06:33:40','2021-11-10 06:33:40',1),(245,'94301764-6e1b-4726-ad34-20572ea774df',1,1,2,1,'FIL02','FILIPINO SA IBA\'T - IBANG DISIPLINA',3,0,3,0,'','2021-11-10 06:33:40','2021-11-10 06:33:40',1),(246,'94301764-6f33-492f-9f3f-9de5fc161ea2',1,1,2,1,'PE03','FIRST AID AND WATER SAFETY',2,0,2,0,'','2021-11-10 06:33:40','2021-11-10 06:33:40',1),(247,'9430687f-2347-4bbd-b336-3138a84be716',1,1,2,2,'ITC05','INFORMATION MANAGEMENT',2,3,2,1,'ITC03','2021-11-10 06:33:40','2021-11-10 06:33:40',1),(248,'9430687f-75a5-407d-9147-20f854401061',1,1,2,2,'ITP05','NETCENTRIC FUNDAMENTALS',2,3,2,1,'ITP04','2021-11-10 06:33:40','2021-11-10 06:33:40',1),(249,'94306ad1-e760-484a-abf4-235ccbb38ce9',1,1,2,2,'ITP06','QUANTITATIVE METHODS (INCL. MODELING & SIMULATION)',3,0,3,0,'ITP02','2021-11-10 06:33:40','2021-11-10 06:33:40',1),(250,'94bd594e-f172-47f9-b3af-f1e35a15d3dd',3,4,1,1,'GE01','AKSDLF;KJSADF',3,0,3,0,'','2021-11-10 06:34:17','2021-11-10 06:39:43',0);
/*!40000 ALTER TABLE `subjects` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `time_schedules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `time_schedules` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `schedule_id` bigint(20) unsigned NOT NULL,
  `room_id` bigint(20) unsigned DEFAULT NULL,
  `start` time NOT NULL,
  `end` time NOT NULL,
  `lab` tinyint(1) NOT NULL DEFAULT 0,
  `monday` tinyint(1) NOT NULL DEFAULT 0,
  `tuesday` tinyint(1) NOT NULL DEFAULT 0,
  `wednesday` tinyint(1) NOT NULL DEFAULT 0,
  `thursday` tinyint(1) NOT NULL DEFAULT 0,
  `friday` tinyint(1) NOT NULL DEFAULT 0,
  `saturday` tinyint(1) NOT NULL DEFAULT 0,
  `sunday` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `time_schedules_schedule_id_foreign` (`schedule_id`),
  KEY `time_schedules_room_id_foreign` (`room_id`),
  CONSTRAINT `time_schedules_room_id_foreign` FOREIGN KEY (`room_id`) REFERENCES `rooms` (`id`) ON DELETE CASCADE,
  CONSTRAINT `time_schedules_schedule_id_foreign` FOREIGN KEY (`schedule_id`) REFERENCES `schedules` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `time_schedules` WRITE;
/*!40000 ALTER TABLE `time_schedules` DISABLE KEYS */;
/*!40000 ALTER TABLE `time_schedules` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_name_unique` (`name`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'superadmin','superadmin@cdd.edu.ph',NULL,'$2y$10$4xT0UWZzZhjztXqcq/IFs.P/7LuJS7xqfQhSClxqrlaV8DBm5/iaO',NULL,'2021-09-06 02:46:31','2021-09-06 02:46:31'),(2,'admin','admin@cdd.edu.ph',NULL,'$2y$10$kRHAxa019x16VS1hUMylLeVIjUzzq4egPHooyFSYJ49iAKznpqPt2','bCaq8SmncDVh7SNVLMJdKqSqVMKbAqoITwjPvphyEaJh2hJFrFW9PlD3mnAF','2021-08-08 21:10:20','2021-08-08 21:10:20'),(32,'Test','test.faculty@cdd.edu.ph',NULL,'$2y$10$j5R2yLtgTX28Vw8RkQ9q4.cs4c3AYprVhyjSfnyHMPj1a9tfgfK9e',NULL,'2021-11-04 07:25:00','2021-11-04 07:32:16');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

